package com.arenafusionmc.server;

import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class ArenaFusionPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        Objects.requireNonNull(getCommand("arenafusion"), "Command 'arenafusion' missing from plugin.yml")
                .setExecutor(this);
        Objects.requireNonNull(getCommand("lobby"), "Command 'lobby' missing from plugin.yml")
                .setExecutor(this);

        getLogger().info("Arena Fusion MC Server foundation enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("Arena Fusion MC Server foundation disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("lobby")) {
            if (!sender.hasPermission("arenafusion.lobby")) {
                sendMessage(sender, "messages.no-permission");
                return true;
            }
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color("&cOnly players can use this command."));
                return true;
            }
            teleportToLobby(player);
            return true;
        }

        if (args.length == 0) {
            sendMessage(sender, "messages.usage");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "info" -> sender.sendMessage(color("&bArena Fusion MC Server &7v" + getDescription().getVersion()
                    + "\n&7Foundation commands: &f/af setlobby, /af lobby, /af reload"));
            case "setlobby" -> {
                if (!sender.hasPermission("arenafusion.admin")) {
                    sendMessage(sender, "messages.no-permission");
                    return true;
                }
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cOnly players can set the lobby. Join the server first."));
                    return true;
                }
                saveLobby(player.getLocation());
                sendMessage(sender, "messages.lobby-saved");
            }
            case "lobby" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cOnly players can use this command."));
                    return true;
                }
                if (!sender.hasPermission("arenafusion.lobby")) {
                    sendMessage(sender, "messages.no-permission");
                    return true;
                }
                teleportToLobby(player);
            }
            case "reload" -> {
                if (!sender.hasPermission("arenafusion.admin")) {
                    sendMessage(sender, "messages.no-permission");
                    return true;
                }
                reloadConfig();
                sendMessage(sender, "messages.config-reloaded");
            }
            default -> sendMessage(sender, "messages.usage");
        }
        return true;
    }

    private void saveLobby(Location location) {
        World world = location.getWorld();
        if (world == null) {
            throw new IllegalStateException("Cannot save a lobby location without a world.");
        }

        getConfig().set("lobby.world", world.getName());
        getConfig().set("lobby.x", location.getX());
        getConfig().set("lobby.y", location.getY());
        getConfig().set("lobby.z", location.getZ());
        getConfig().set("lobby.yaw", location.getYaw());
        getConfig().set("lobby.pitch", location.getPitch());
        saveConfig();
    }

    private void teleportToLobby(Player player) {
        if (!getConfig().contains("lobby.world")) {
            sendMessage(player, "messages.lobby-not-set");
            return;
        }

        String worldName = getConfig().getString("lobby.world", "");
        World world = getServer().getWorld(worldName);
        if (world == null) {
            player.sendMessage(color("&cThe configured lobby world '" + worldName + "' is not loaded."));
            return;
        }

        Location location = new Location(
                world,
                getConfig().getDouble("lobby.x"),
                getConfig().getDouble("lobby.y"),
                getConfig().getDouble("lobby.z"),
                (float) getConfig().getDouble("lobby.yaw"),
                (float) getConfig().getDouble("lobby.pitch")
        );

        player.teleportAsync(location).thenAccept(success -> {
            if (success) {
                player.sendMessage(message("messages.lobby-teleported"));
            } else {
                player.sendMessage(color("&cTeleport failed."));
            }
        });
    }

    private void sendMessage(CommandSender sender, String path) {
        sender.sendMessage(message(path));
    }

    private String message(String path) {
        String prefix = getConfig().getString("messages.prefix", "&8[&bArenaFusion&8] ");
        String body = getConfig().getString(path, "&cMissing message: " + path);
        return color(prefix + body);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
