# Arena Fusion MC Server

A starter Paper plugin project for a Minecraft arena server. This foundation intentionally excludes weapon and combat mechanics.

## Included

- Paper API dependency and Java 21 Maven setup
- `plugin.yml` and configurable `config.yml`
- `/af info` — show plugin information
- `/af setlobby` — save your current location as the lobby (admin)
- `/af lobby` and `/lobby` — teleport to the configured lobby
- `/af reload` — reload the plugin configuration (admin)
- Permission nodes for administration and lobby access

## Requirements

- A Paper server compatible with Minecraft 1.21.x
- Java 21 JDK for building
- Maven 3.9+ for building

The Maven dependency is set to Paper API `1.21.11-R0.1-SNAPSHOT`. If Paper's repository does not resolve that version in your environment, check the Paper API version published for your exact server build and update the `paper-api` version in `pom.xml`.

## Build the JAR

On a computer with Java 21 and Maven installed:

```bash
mvn clean package
```

The output should be:

```text
target/ArenaFusionMCServer.jar
```

Copy that JAR into the server's `plugins/` folder, then restart the Paper server.

## Commands

| Command | Permission | Purpose |
|---|---|---|
| `/af info` | none | Show plugin version and commands |
| `/af setlobby` | `arenafusion.admin` | Save your current position as lobby |
| `/af lobby` | `arenafusion.lobby` | Teleport to the lobby |
| `/lobby` | `arenafusion.lobby` | Teleport to the lobby |
| `/af reload` | `arenafusion.admin` | Reload `config.yml` |

Admins (`op`) have `arenafusion.admin` by default. Players can use lobby commands by default.

## Current status

This is the initial source foundation. It has not been compiled or tested against a live server in this environment. Test it on a separate server before using it on a public server.
